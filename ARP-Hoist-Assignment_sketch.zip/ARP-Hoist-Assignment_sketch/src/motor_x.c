#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>


float posx=0.0;


int send_info(float posx)
{
    while (1)
    {
        int fd2;
        char *myfifo2 = "/tmp/myfifo3";
        char px[80];
        mkfifo(myfifo2, 0666);
        fd2 = open(myfifo2, O_WRONLY);
        sprintf(px, "%f", posx);
        write(fd2, px, strlen(px) + 1);
        usleep(100000);
        close(fd2);
    }
}
int rec_info()
{
    int fd1;
    // Pipe to receive from command
    char *myfifo = "/tmp/myfifo";
    mkfifo(myfifo, 0666);
    // Pipe to send to inspection
    char vel[80];
    char px[80];
    char format_string[80] = "%f";

    float posx, posy, lim_x;
    float velx, vely, dt;
    double mean;
    velx = 0;
    vely = 0;
    posx = 0.0;
    posy = 0.0;
    dt = 0.5;
    lim_x = 38;
    float vx = 0;

    while(1){
    printf("posx: %f\n", posx);
    fd1 = open(myfifo, O_RDONLY);
    read(fd1, vel, 80);
    sscanf(vel, format_string, &velx);
    close(fd1);
    posx = posx + dt * velx;
    if (posx > lim_x)
    {
        posx = lim_x;
    }
    // velx = velx - 0.25;
    if (posx < -lim_x)
    {
        posx = -lim_x;
    }
    return posx;
    usleep(100000);
    }

}

int main()
{

    /*
    Movement process
    */



        // write posx in the px string and send to inspection

        /* fork a child process */
        pid_t pid = fork();

        if (pid < 0)
        { /* error occurred */
            fprintf(stderr, "Fork Failed");
            return 1;
        }

        else if (pid == 0)
        { /* child process */
            // printf("I'm the child \n"); /* you can execute some commands here */
            send_info(posx);
 
            
        }

        else
        { /* parent process */
            /* parent will wait for the child to complete */
            // wait(NULL);

            /* When the child is ended, then the parent will continue to execute its code */
            posx=rec_info();
            printf("Child Complete \n");
        }


        /*fd = open(myfifo2, O_WRONLY);
        sprintf(px, "%f",posx);
        write(fd, px, strlen(px) + 1);
        close(fd);*/

        // Read the vel from command and compute posx

        // velx = velx + 0.25;

        // posx = posx + dt * velx;
        // printf("posx: %f\n", posx);
        // fd = open(myfifo,O_RDONLY);
        // read(fd, vel, 80);
        // sscanf(vel, format_string, &velx,&vely);
        // printf("velx: %f,vely: %f\n", velx,vely);
        // close(fd);
    // Terminate
    // endwin();
    //return 0;
}