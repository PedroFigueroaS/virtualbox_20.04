konsole  -e ./bin/command &
konsole  -e ./src/motor_x &
konsole  -e ./src/arp_a1 &
